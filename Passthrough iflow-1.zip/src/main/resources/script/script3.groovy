import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def parse = new XmlParser().parseText(body);
	def messageLog = messageLogFactory.getMessageLog(message);
	    //Read initial property values
       map = message.getHeaders();
         def Parm1 = map.get("Parm1");
         def filename = map.get("Parm2");

	if(messageLog != null){
			message.setProperty("InputPayload", body);
			message.setProperty("MsgStatus", 'MapFail');
			message.setHeader("SAP_ApplicationID", Parm1);

	}
       
	return message;
}