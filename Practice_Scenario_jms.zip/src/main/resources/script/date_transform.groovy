import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.*;
import com.sap.it.api.mapping.*;




public void mapAddressLine(String[] addressLines, Output output){
    for(String addressLine: addressLines){
        String[] values = addressLine.split(" ");
        for(String value: values){
            output.addValue(value);
        }
    }    
}


// New function to get current date plus 90 days
public String getDateAfter90Days(String currentDateStr) {
    def sdf = new java.text.SimpleDateFormat("yyyy-MM-dd") // Define the date format
    def currentDate = sdf.parse(currentDateStr) // Parse the input string to Date
    def calendar = Calendar.getInstance() // Get an instance of Calendar
    calendar.setTime(currentDate) // Set the current date to the calendar
    calendar.add(Calendar.DAY_OF_YEAR, 90) // Add 90 days to the calendar
    
    def newDate = calendar.getTime() // Get the updated date after 90 days
    return sdf.format(newDate) // Return the date formatted as a string
}
