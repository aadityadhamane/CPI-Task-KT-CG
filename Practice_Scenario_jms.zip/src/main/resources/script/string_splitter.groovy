// Get the current date
def currentDate = currentDate()

// Calculate the date 90 days after the current date
def dateAfter90Days = dateAfter(currentDate, 90)

return dateAfter90Days
