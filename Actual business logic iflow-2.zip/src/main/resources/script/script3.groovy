import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    
    // Check if the body is empty or null
    if (body == null || body.trim().isEmpty()) {
        if (messageLog != null) {
            messageLog.addAttachmentAsString("Error", "Empty input data", "text/plain");
            message.setProperty("MsgStatus", "Error");
        }
        return message;
    }
    
    // Split the input based on pipe separator
    def data = body.split("\\|")
    
    // Check if the data has the correct number of fields
    if (data.size() != 5) {
        if (messageLog != null) {
            messageLog.addAttachmentAsString("Error", "Invalid data format", "text/plain");
            message.setProperty("MsgStatus", "Error");
        }
        return message;
    }
    
    // Parse each field from the input data
    def empid = data[0]
    def firstname = data[1]
    def lastname = data[2]
    def resignedstatus = data[3]
    def lastworkingday = data[4]
    
    // Create a map of parsed data
    def employeeData = [
        "empid"           : empid,
        "firstname"       : firstname,
        "lastname"        : lastname,
        "resignedstatus"  : resignedstatus,
        "lastworkingday"  : lastworkingday
    ]
    
    // Convert the map to a JSON string (for further processing or logging)
    def jsonString = JsonOutput.toJson(employeeData)
    
    // Log the employee data in JSON format
    if (messageLog != null) {
        messageLog.addAttachmentAsString("EmployeeData", jsonString, "application/json");
        message.setProperty("EmployeeData", jsonString);
        message.setProperty("MsgStatus", "MapSuccess");
    }
    
    return message;
}
