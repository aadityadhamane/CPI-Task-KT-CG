import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlParser;

def Message processData(Message message) {
    // Retrieve the body of the message as a String
    def body = message.getBody(java.lang.String) as String;
    
    // Parse the XML from the body
    def parse = new XmlParser().parseText(body);
    
    // Log the message if needed
    def messageLog = messageLogFactory.getMessageLog(message);
    
    // Read initial property values (headers)
    def map = message.getHeaders();

    // Add message logging for debug purposes
    if (messageLog != null) {
        messageLog.addAttachmentAsString("InputPayload", body, "text/plain");
        message.setProperty("MsgStatus", "MapFail");
    }
    
    // Return the message with modifications
    return message;
}
